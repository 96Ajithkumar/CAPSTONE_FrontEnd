export const ITEM_CATELOG = "Item Catelog";
export const HOME = "Home";
